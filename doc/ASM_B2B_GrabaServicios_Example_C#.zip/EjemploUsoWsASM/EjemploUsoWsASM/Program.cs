﻿using System;
using System.Xml;
using EjemploUsoWsASM.com.asmred.www;

namespace EjemploUsoWsASM
{
    class Program
    {
        static void Main(string[] args)
        {
            b2b asm = new b2b();

            XmlDocument docin = new XmlDocument();
            docin.Load(@"c:\envio.xml");
            XmlNode docout = asm.GrabaServicios(docin);

            Console.Write(docout.InnerXml);
            Console.ReadKey();
        }
    }
}
